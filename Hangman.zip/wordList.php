<?php
$words = ["testa"];