const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

function resetMan() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawGallows();
}

drawGallows();
function drawGallows() {
  with (ctx) {
    beginPath();
    moveTo(50, 550);
    lineTo(250, 550);
    moveTo(150, 550);
    lineTo(150, 50);
    lineTo(400, 50);
    moveTo(150, 200);
    lineTo(250, 50);
    lineWidth = 12;
    strokeStyle = "black";
    stroke();

    beginPath();
    moveTo(400, 50);
    lineWidth = 8;
    strokeStyle = "tan";
    lineTo(400, 100);
    stroke();
  }
}

function drawParts(num) {
  switch (num) {
    case 1:
      head();
      break;
    case 2:
      body();
      break;
    case 3:
      leftLeg();
      break;
    case 4:
      rightLeg();
      break;
    case 5:
      leftArm();
      break;
    case 6:
      rightArm();
      break;
    case 7:
      face();
      break;
  }
}

function head() {
  ctx.lineWidth = 8;
  ctx.strokeStyle = "black";
  ctx.lineWidth = 5;
  ctx.beginPath();
  ctx.arc(400, 150, 50, Math.PI * 2, false);
  ctx.stroke();
}

function face() {
  with (ctx) {
    beginPath();
    //eyes
    fillStyle = "red";
    ctx.font = "bold 24px sans-serif";
    fillText("x", 375, 130);
    fillText("x", 410, 130);
    fillStyle = "white";

    //nose
    moveTo(400, 145);
    lineTo(400, 155);

    //mouth
    lineWidth = 2;
    moveTo(370, 170);
    lineTo(430, 170);
    stroke();
    save();

    //toungue
    beginPath();
    moveTo(405, 170);
    lineWidth = 0;
    quadraticCurveTo(412, 195, 420, 170);
    closePath();
    fillStyle = "red";
    fill();
    strokeStyle = "red";
    stroke();
  }
}

function body() {
  with (ctx) {
    beginPath();
    moveTo(400, 200);
    lineWidth = 8;
    strokeStyle = "black";
    lineTo(400, 320);
    stroke();
  }
}

function rightLeg() {
  with (ctx) {
    beginPath();
    moveTo(400, 320);
    lineWidth = 8;
    strokeStyle = "black";
    lineTo(450, 420);
    lineTo(470, 420);
    stroke();
  }
}

function leftLeg() {
  with (ctx) {
    beginPath();
    moveTo(400, 320);
    lineWidth = 8;
    strokeStyle = "black";
    lineTo(350, 420);
    lineTo(330, 420);
    stroke();
  }
}

function leftArm() {
  with (ctx) {
    beginPath();
    moveTo(400, 220);
    lineWidth = 8;
    strokeStyle = "black";
    lineTo(350, 250);
    lineTo(330, 250);
    stroke();
  }
}

function rightArm() {
  with (ctx) {
    beginPath();
    moveTo(400, 220);
    lineWidth = 8;
    strokeStyle = "black";
    lineTo(450, 250);
    lineTo(470, 250);
    stroke();
  }
}
