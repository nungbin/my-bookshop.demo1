<?php
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);

include 'wordList.php';
session_start();
$letterArray = [];

/****

****************TO DO*******************

1. if user request a new word - 
	- generate a random number  for the wordlist index
	- store the word in a session variable
	-create a guesses session variable
	-populate the guesses session variable with the "_" matching the length of the word
	-echo the guesses session variable as a string separated by spaces  "_ _ _ "
	
2. if user posts a guessed letter -
	-compare the letter to all of the letters in the word session variable
	if it is in the word:
		- replace all of the _ with the guess in the guesses session variable at the index of the letter of the word
		- echo the guesses session variable as a string separated by spaces
	if it is not in the word:
		echo the letter they guessed ( or some other way to tell them it was wrong)

		
3. if user requests the answer, echo the word session variable (if you can, you really should track the number of incorrect guesses in a session variable and only give them the answer if they have guessed 7 times)


*/
if ($_SERVER['REQUEST_METHOD'] === 'GET'){
	if($_GET['request'] === 'new word'){
		$_SESSION['randomIndex'] = rand(0, count($words) -1);
		//$word = str_shuffle($words[$_SESSION['randomIndex']]);
		$word = $words[$_SESSION['randomIndex']];
		$_SESSION['numberOfGuesses'] = 0;
		$_SESSION['wrongGuesses'] = 0;
		$_SESSION['actualWord'] = $word;
		for ($x = 0; $x < strlen($word); $x++) {
			array_push($letterArray, "_");			
		}
		$_SESSION['letterArray'] = $letterArray;
		echo implode(" ", $letterArray);
	}
}else if($_SERVER['REQUEST_METHOD'] === 'POST') {
	if($_POST['request'] === 'guess'){
		$_SESSION['numberOfGuesses']+=1;
		$guessedLetter = strtolower($_POST['input']);
		//$word = strtolower($words[$_SESSION['randomIndex']]);
		$word = $_SESSION['actualWord'];
		$arrWord = str_split($word);
		$correct = 0;
		$letterArray = $_SESSION['letterArray'];
		for ($count = 0; $count < count($arrWord); $count++)
		{
			if($guessedLetter == $arrWord[$count]){
				$letterArray[$count] = $guessedLetter;
				$_SESSION['letterArray'] = $letterArray;
				$correct += 1;
			}
		}

		if($correct == 0){
			$_SESSION['wrongGuesses']+=1;
			echo "Wrong Guess";
		}
		// elseif ($arrWord === $_SESSION['letterArray']) {
		// 	echo "Correct Guess";
		// } 
		else {
			echo implode(" ", $letterArray);
		}
	}
}


/*
if(strPos($_SESSION['word'], $_POST['guess']) !==false){
		for($i = 0; $i < strlen($_SESSION['word']); $i++){
		if($_SESSION['word'][$i] == $_POST['guess']){
			                 
		}
		}
}
*/