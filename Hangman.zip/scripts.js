var guess = "";
//**handle on the server*** var guesses = [];
//**handle on the server*** var currentWord = "";
newWord();
function newWord() {
  guess = "";
  $("#feedback").text("");
  totalWrong = 0;
  resetMan();

  //**handle on the server***
  /*
	//generate a new random word that the user will guess
	var rand = Math.floor(Math.random()*words.length);
	currentWord = words[rand];
	
	//create a guesses array of _ the length of the word
	guesses=[currentWord.length];
	for(var i=0; i<currentWord.length; i++){
		guesses[i] = "_";
	}		
	 */
  //$("#answer").html(guesses.join("&nbsp;")); // <--set the text with the result from the server
}

$("form").on("submit", function (e) {
  e.preventDefault();
  guess = $("#guessInput").val().toLowerCase();
  $("#guessInput").val("");
  $.ajax({
    type: "POST",
    url: "words.php",
    data: { request: "guess", input: guess },
    success: function (response) {
      console.log(response);
    },
    error: function (error) {
      alert("error communication with the server" + error);
    },
  });
  /*
	send the guess to the server, 
	server will echo the string with the letters in place if correct
	ex. "_O_TO_" - guess was correct
	OR 
	server echos the letter that they guessed, but guess was wrong
	*/

  //server handles this
  //if the letter is not in the word
//   if (currentWord.indexOf(guess) === -1) {
//     incorrect();
//   } else {
//     correct();
//   }
});

/*handle this in the response from the server
function correct(){
	//replace each matching _ index in the guesses array with the letter:
	for(var i=0; i<currentWord.length; i++){
		if(currentWord[i]==guess) guesses[i] = guess.toUpperCase();
	}
	//update the answer with the guesses array converted to a string using join
	$("#answer").html(guesses.join("&nbsp;"));
	
	//find out if the word is solved
	checkWinLose();
}
*/

//nothing needs to change in the incorrect function
function incorrect() {
  //add the incorrectly guessed letter to the list of wrong guesses
  var incorrectGuesses = $("#feedback").text();
  if (incorrectGuesses.indexOf(guess.toUpperCase()) === -1) {
    if (incorrectGuesses == "") {
      incorrectGuesses = guess.toUpperCase();
    } else {
      incorrectGuesses = incorrectGuesses + ", " + guess.toUpperCase();
    }
    $("#feedback").text(incorrectGuesses);

    totalWrong++;
    drawParts(totalWrong);

    //find out if the man is hung
    checkWinLose();
  } else {
    alert("you already guessed the letter " + guess.toUpperCase());
  }
}

function checkWinLose() {
  //if there are no more _ in the word, you win
  if (guesses.indexOf("_") === -1) {
    $("#feedback").text("You got it!");
    setTimeout(function () {
      newWord();
    }, 2000);
  } else if (totalWrong == 7) {
    // 7 wrong guesses, you lose
    /*
			we don't know the current word, so we need to ask the computer for the current word in the next line, replace current word with the response from the server.
		*/
    $("#feedback").html(
      "Sorry, that's incorrect. The answer was <span style='color:red;'>" +
        currentWord +
        "</style>"
    );
    setTimeout(function () {
      newWord();
    }, 4000);
  }
}


function resetMan() {
  $.ajax({
    type: "GET",
    url: "words.php",
    data: { request: "new word" },
    success: function (response) {
      console.log(response);
      $("#answer").html(response);
    },
    error: function (error) {
      alert("error communication with the server" + error);
    },
  });  
}