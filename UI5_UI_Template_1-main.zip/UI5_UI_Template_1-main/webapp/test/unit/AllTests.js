sap.ui.define([
	"ui5_ui_template_1/test/unit/controller/RootView.controller"
], function () {
	"use strict";
});
