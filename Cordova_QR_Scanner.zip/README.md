# Cordova_QR_Scanner

A sample cordova app to scan QR code and Barcode

Add com.phonegap.plugins.barcodescanner plugin to test the app
