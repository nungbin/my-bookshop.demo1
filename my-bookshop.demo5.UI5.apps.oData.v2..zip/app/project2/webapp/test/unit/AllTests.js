sap.ui.define([
	"project2/project2/test/unit/controller/RootView.controller"
], function () {
	"use strict";
});
